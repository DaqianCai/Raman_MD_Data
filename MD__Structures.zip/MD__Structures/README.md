# Molecular-dynamics structures and simulation inputs

This repository provides the complete molecular structures and input files for the molecular-dynamics simulations of 1.5 m Zn(OTf)2 aqueous electrolytes. It is intended to allow readers to inspect the constructed systems and to perform independent analyses.

## Simulated models

- `model_a`: 100 Zn2+, 200 OTf-, and 3701 H2O.
- `model_b`: model A plus 38 gelatin molecules.
- `model_c`: model B plus 115 PNE molecules.

The water, Zn2+, and OTf- counts are identical among the three models. Gelatin and PNE are the variables introduced in models B and C, respectively.

## Contents

- `01_initial_structures/`: complete initial configurations for each model.
- `02_equilibrated_structures/`: coordinate files after NPT equilibration and at the terminal production state. Presentation-ready PDB files are also provided for convenient visualization.
- `03_simulation_inputs/`: Packmol inputs, component structures, GROMACS topology files, MD parameter files, and production-run TPR files.
- `00_metadata/`: a concise description of the data scope.

The coordinate and input files are provided so that readers may conduct analyses of their choice. Numerical analysis outputs and full trajectories are not included in this repository.

## Before release

Please add the associated paper citation, GROMACS version, force-field references, and a license selected by the authors.
