# Data scope

This repository contains the structural and simulation-input data needed to inspect and reproduce the three molecular-dynamics model systems.

For each model, the archive includes:

1. The complete initial configuration.
2. Coordinate files following NPT equilibration and at the terminal production state.
3. Component coordinates and the Packmol input used to construct the system.
4. GROMACS topology files, MD parameter files, and the production-run TPR file.

The archive is intentionally limited to structures and simulation inputs. Readers may use the supplied coordinate files and simulation settings to carry out independent structural or statistical analyses. Numerical analysis outputs, visual renderings, and full trajectories are not included.
