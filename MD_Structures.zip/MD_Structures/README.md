# Raman and Molecular Dynamics Data

This repository contains the Raman datasets used for the reconstruction of Figure S30b and the molecular dynamics model files for the Zn(OTf)₂-based electrolytes investigated in this study.

## Molecular Dynamics Models

Three electrolyte models were constructed:

- **Model A (LE):** 100 Zn²⁺, 200 OTf⁻, and 3701 H₂O molecules
- **Model B (CGel):** Model A plus 38 gelatin molecules
- **Model C (PNE-CGel):** Model B plus 115 PNE molecules

All three models contain the same numbers of Zn²⁺ ions, OTf⁻ ions, and water molecules. The Zn(OTf)₂ concentration is 1.5 mol kg⁻¹ H₂O.

## Simulation Protocol

Initial configurations were generated using Packmol with a minimum intermolecular distance of 2.0 Å. The systems were described using an OPLS-AA-compatible fixed-charge force field. SPC/E was used for water, CL&P-type parameters were used for OTf⁻, and LigParGen-derived parameters were used for gelatin and PNE. Zn²⁺ was treated as a nonbonded divalent ion with a charge of +2.0 e. No charge scaling or bonded Zn–ligand interactions were applied.

Each model was subjected to the following workflow:

1. Steepest-descent energy minimization
2. NVT temperature equilibration at 298.15 K
3. Isotropic NPT equilibration at 298.15 K and 1 bar to stabilize the system volume and density
4. NVT production molecular dynamics at 298.15 K

A total production trajectory of 20 ns was generated for each model. Periodic boundary conditions were applied in all three directions. Long-range electrostatic interactions were treated using particle-mesh Ewald, with a 1.0 nm cutoff for electrostatic and van der Waals interactions. Hydrogen-containing bonds were constrained using the LINCS algorithm.

## Repository Contents

The molecular dynamics folders contain the initial structures, equilibrated structures, topology files, force-field parameters, and simulation parameter files. The Raman folder contains the original spectra and the datasets used to reconstruct Figure S30b.

Preprocessed RDF, coordination-number, hydrogen-bond, and diffusion-coefficient data are not included. Users may perform independent analyses directly from the provided structures, trajectories, and simulation input files.

## Reproducibility

The files are provided for inspection and independent analysis of the molecular models used in this study. File names and model labels are consistent across the structure, topology, and parameter files.